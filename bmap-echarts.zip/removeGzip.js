const fs = require('fs')
const vueConfig = require('./vue.config.js')
let outputDir = vueConfig.outputDir === undefined ? 'dist' : vueConfig.outputDir
fs.access(`${outputDir}.zip`, (err) => {
  if (err) {
    console.log(err)
    if (err.code === 'ENOENT') {
      console.error(`${outputDir}.zip不存在`)
    }
  } else {
    console.log(`${outputDir}.zip存在`)
    // 删除zip文件
    fs.unlink(`${outputDir}.zip`, (err) => {
      if (err) {
        console.log(err)
        console.log('删除失败')
      } else {
        console.log('删除成功')
      }
    })
  }
})
