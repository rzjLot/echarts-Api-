const compressing = require('compressing')
const vueConfig = require('./vue.config.js')

let outputDir = vueConfig.outputDir === undefined ? 'dist' : vueConfig.outputDir

// 压缩文件
compressing.zip.compressDir(outputDir, `${outputDir}.zip`)
  .then(() => {
    console.log('success')
  })
  .catch(err => {
    console.error(err)
  })
