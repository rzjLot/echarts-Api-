const { getLocalAddress } = require('./build/utils')
const localServer = getLocalAddress()
let commonServerApi = 'http://baidu.com'
let proxyConfig = {
  '/xxx': commonServerApi,
}
const proxy = {}
for (let key in proxyConfig) {
  proxy[key] = {
    target: proxyConfig[key],
    changeOrigin: true,
    cookieDomainRewrite: {
      '*': localServer // 把相应的 cookie 域都设置成 localhost
    },
    withCredentials: true,
    headers: {
      Referer: proxyConfig[key]
    }
  }
}
const path = require('path')
module.exports = {
  css: {
    loaderOptions: {
      sass: {
      }
    }
  },
  chainWebpack: config => {
    const fileRule = config.module.rule('file')
    fileRule.uses.clear()
    fileRule
      .test(/\.swf$/)
      .exclude.add(path.resolve(__dirname, './src/icons'))
      .end()
      .use('file-loader')
      .loader('file-loader')
  },
  devServer: {
    proxy
  },
  // 打包后文件路径
  // 打包文件名
  outputDir: 'bmap-echarts',
  assetsDir: 'static',
  indexPath: 'index.html',
  publicPath: '/bmap-echarts/'
}
