<template>
  <div class="home">
    <h3>百度地图API获取地图的数据，用echarts渲染</h3>
    <MapVue />
  </div>
</template>

<script>
// @ is an alias to /src
import MapVue from './components/MapVue.vue'

export default {
  name: 'mapView',
  components: {
    MapVue
  }
}
</script>

<style lang="scss">
  .home {
    height: 100%;
    background: rgba(6, 1, 107, 1);
    h3 {
      color: #fff;
      line-height: 50px;
    }
  }
</style>
