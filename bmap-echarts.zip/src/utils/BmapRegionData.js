import { cityArea } from './mapCityArea'
import echarts from 'echarts'
// 获取地图轮廓数据
export function getMapData (params) {
  // 百度地图实例方法
  let bdary = new window.BMap.Boundary()
  // 用于存储轮廓数据的对象和格式
  let mapObj = {
    type: 'FeatureCollection',
    features: []
  }
  let mapData = []
  // 因为每一个省份是由它的地级市轮廓组合而成，这里是获取子层的轮廓
  let PromiseArr = params.mapData.map(function (item) {
    return new Promise((resolve, reject) => {
      let nameData = ''
      let searchName = ''
      if (item.indexOf(',') > -1) {
        let arr = item.split(',')
        nameData = arr[arr.length - 1]
        searchName = item.replace(/,/g, '')
      } else {
        searchName = nameData = item
      }
      // 部分真实地区的名字与实际区需要使用的搜索的名字映射表
      /* 
        const cityArea = {
          '北京': '北京市',
          '北京市': '北京市',
          '上海': '上海市',
          '上海市': '上海市',
          '重庆': '重庆市',
          '重庆市': '重庆市',
          '天津': '天津市',
          '天津市': '天津市',
          '广东省深圳市光明新区': '光明区',
          '广东省佛山市南海区': '南海区'
        }
      */
      searchName = cityArea[searchName] ? cityArea[searchName] : searchName
      bdary.get(searchName, function (rs) {
        let data = rs.boundaries
        let dataStrArr = ''
        let arr = []
        mapData = []
        let mapDataObj = {
          type: 'Feature',
          properties: { name: item },
          geometry: { type: 'Polygon', coordinates: [] }
        }
        if (data.length === 0) {
          resolve('')
        }
        // 子层的轮廓可能不是；连续的
        for (let m = 0; m < data.length; m++) {
          arr = []
          dataStrArr = data[m].split(';')
          // 每个类型的数据不一样
          switch (params.type) {
            case 'all': mapDataObj = {
              type: 'FeatureCollection',
              features: []
            }
              break
            case 'province': mapDataObj = {
              type: 'Feature',
              geometry: { type: 'Polygon', coordinates: [] },
              properties: { name: m === 0 ? nameData : nameData + ':' + m }
            }
              break
            case 'city': mapDataObj = {
              type: 'Feature',
              properties: { name: m === 0 ? nameData : nameData + ':' + m },
              geometry: { type: 'Polygon', coordinates: [] }
            }
              break
          }
          // 轮廓的每个点，经纬度组合一个点的数组
          for (let i = 0; i < dataStrArr.length; i++) {
            arr.push([Number(dataStrArr[i].split(',')[0]), Number(dataStrArr[i].split(',')[1])])
          }
          mapDataObj.geometry.coordinates = [arr]
          if (data.length === 1) {
            resolve(mapDataObj)
          } else {
            mapData.push(mapDataObj)
          }
        }
        if (data.length > 1) {
          resolve(mapData)
        }
      })
    })
  })
  Promise.all(PromiseArr).then(res => {
    let data = res.filter(function (item) {
      return item
    })
    let isNotArea = false
    if (data.length === 1) {
      isNotArea = true
    }
    data = data.reduce((r, item) => r.concat(item), [])
    mapObj.features = [...data]
    // echart渲染区域
    echarts.registerMap(params.mapName, mapObj)
    bdary = null
    PromiseArr = null
    mapObj = null
    mapData = null
    params.callback(params.callbackData, data, isNotArea)
  }).catch(() => {
    bdary = null
    PromiseArr = null
    mapObj = null
    mapData = null
  })
}
