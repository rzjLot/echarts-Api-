export const provinceList = [
  {
    provinceId: '1',
    provinceName: '广东省',
    nums: 100
  },
  {
    provinceId: '2',
    provinceName: '北京市',
    nums: 90
  }
]

// 省份下有数据的城市
export const cityList = [
  {
    regionId: '342',
    regionIdName: '广州市',
    communityNums: '4'
  },
  {
    regionId: '342',
    regionIdName: '深圳市',
    communityNums: '4'
  }
]
// 省份下的所有地级市
export const allCityList = [
  '广州市', '深圳市', '东莞市', '佛山市', '惠州市', '汕尾市', '汕头市', '潮州市', '揭阳市', '河源市', '梅州市', '韶关市',
  '清远市', '肇庆市', '云浮市', '中山市', '珠海市', '江门市', '阳江市', '茂名市', '湛江市'
]

// 城市下面有数据的区
export const areaList = [
  {
    regionId: '302',
    regionIdName: '南山区',
    communityNums: '2'
  },
  {
    regionId: '303',
    regionIdName: '福田区',
    communityNums: '1'
  }
]
// 城市下所有的区
export const allAreaList = [
  '罗湖区', '福田区', '南山区', '宝安区', '光明区', '龙华区', '龙岗区', '盐田区', '大鹏新区', '坪山区', 
]