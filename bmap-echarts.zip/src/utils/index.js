// 地图
export function getMapOption (options) {
  let arr = []
  let obj = {}
  for (let i = 0; i < options.length; i++) {
    arr.push(options[i].provinceName)
  }
  let provinceArr = dislodge(arr)
  let regionsArr = []
  for (let i = 0; i < provinceArr.length; i++) {
    regionsArr.push(
      {
        name: provinceArr[i],
        itemStyle: {
          color: '#25a9e1',
          areaColor: '#25a9e1',
          opacity: 1,
          borderWidth: 1,
          borderColor: '#333'
        },
        emphasis: {
          itemStyle: {
            color: '#25a9e1',
            opacity: 1,
            borderWidth: 5,
            borderColor: '#333'
          },
          label: {
            show: false,
            textStyle: {
              color: '#fff',
              fontSize: 3,
              backgroundColor: 'rgba(7, 23, 62, 0.8)',
              borderWidth: 1
            }
          }
        }
      }
    )
  }
  obj.option = {
    series: [
      {
        name: 'map3D',
        type: 'map3D',
        map: 'china',
        z: 5,
        zlevel: 10,
        itemStyle: {
          color: '#07517e',
          areaColor: '#07517e',
          opacity: 0.5,
          borderWidth: 0.4,
          borderColor: '#11c6db'
        },
        viewControl: {
          maxBeta: 0, // 地图左右移动
          minBeta: 0, // 地图左右移动
          minAlpha: 50, // 地图上下移动
          maxAlpha: 50, // 地图上下移动
          alpha: 50, // 地图上下移动初始值
          beta: 0, // 地图左右移动初始值
          distance: 100, // 看地图的远近
          zoomSensitivity: 0, // 设置为0无法进行缩放
          orthographicSize: 100// 地图投影
        },
        label: {
          show: false,
          textStyle: {
            color: '#fff',
            fontSize: 14,
            backgroundColor: 'rgba(7, 23, 62, 0.8)',
            borderColor: '#1072e2',
            borderWidth: 14
          }
        },
        emphasis: { // 当鼠标放上去  地区区域是否显示名称
          label: {
            show: false,
            textStyle: {
              color: '#fff',
              fontSize: 14,
              backgroundColor: 'rgba(0,23,11,0)'
            }
          },
          itemStyle: {
            color: '#07517e',
            areaColor: '#07517e'
          }
        },
        light: { // 光照阴影
          main: {
            color: '#fff', // 光照颜色
            intensity: 1.2, // 光照强度
            shadowQuality: 'high', // 阴影亮度
            shadow: false, // 是否显示阴影
            alpha: 55,
            beta: 10
          },
          ambient: {
            intensity: 0.3,
            color: '#35acd4'
          }
        },
        data: regionsArr
      },
      {
        name: 'map',
        type: 'map',
        silent: true,
        mapType: 'china',
        zoom: 1.2,
        z: -1,
        zlevel: 0,
        label: {
          normal: {
            show: false
          },
          emphasis: {
            show: false
          }
        },
        itemStyle: {
          normal: {
            color: 'transparent',
            areaColor: 'transparent',
            opacity: 0
          }
        },
        data: [
          {
            name: '南海诸岛',
            itemStyle: {
              normal: {
                areaColor: '#25a9e1',
                color: '#25a9e1',
                opacity: 0.5
              },
              emphasis: {
                areaColor: '#25a9e1',
                color: '#25a9e1',
                opacity: 0.5
              }
            }
          }
        ]
      }
    ]
  }
  obj.arr = provinceArr
  return obj
}

//  把获取到的省份名字转化去除省字
export function dislodge (data) {
  let arr = []
  for (let i = 0; i < data.length; i++) {
    if (data[i].indexOf('省') > -1) {
      arr.push(data[i].replace('省', ''))
    } else if (data[i].indexOf('新疆') > -1) {
      arr.push('新疆')
    } else if (data[i].indexOf('西藏') > -1) {
      arr.push('西藏')
    } else if (data[i].indexOf('内蒙古') > -1) {
      arr.push('内蒙古')
    } else if (data[i].indexOf('广西') > -1) {
      arr.push('广西')
    } else if (data[i].indexOf('宁夏') > -1) {
      arr.push('宁夏')
    } else if (data[i].indexOf('香港') > -1) {
      arr.push('香港')
    } else if (data[i].indexOf('澳门') > -1) {
      arr.push('澳门')
    } else if (data[i].indexOf('市') > -1) {
      arr.push(data[i].replace('市', ''))
    }
  }
  return arr
}

// 显示省份下的城市项目
export function drawing (options) {
  let option = null
  let arr = []
  const mapObj = {
    '西藏': 100,
    '广西': 100,
    '湖北': 120,
    '吉林': 100,
    '青海': 100,
    '湖南': 150,
    '福建': 150,
    '云南': 150,
    '重庆': 150,
    '天津': 150,
    '海南': 180,
    '江西': 180,
    '河北': 180,
    '安徽': 180,
    '宁夏': 180,
    '陕西': 210,
    '山西': 230,
    '澳门': 230,
    '广东': 120,
    '浙江': 120,
    '贵州': 120,
    '四川': 120,
    '新疆': 120,
    '内蒙古': 120,
    '河南': 120,
    '江苏': 120,
    '山东': 120,
    '上海': 120,
    '北京': 120,
    '辽宁': 120,
    '黑龙江': 120,
    '香港': 120,
    '台湾': 120
  }
  for (let i = 0; i < options.citys.length; i++) {
    arr.push({
      name: options.citys[i].cityName,
      itemStyle: {
        color: '#25a9e1',
        areaColor: '#25a9e1',
        opacity: 1,
        borderWidth: 1,
        borderColor: '#333'
      },
      emphasis: {
        itemStyle: {
          color: '#25a9e1',
          areaColor: '#25a9e1',
          opacity: 1,
          borderWidth: 1,
          borderColor: '#333'
        }
      }
    })
  }
  option = {
    series: [
      {
        name: 'map3D',
        type: 'map3D',
        map: options.provincesName,
        itemStyle: {
          color: '#07517e',
          areaColor: '#07517e',
          opacity: 0.5,
          borderWidth: 0.4,
          borderColor: '#11c6db'
        },
        viewControl: {
          projection: 'perspective',
          maxBeta: 0, // 地图左右移动
          minBeta: 0, // 地图左右移动
          minAlpha: 50, // 地图上下移动
          maxAlpha: 50, // 地图上下移动
          alpha: 50, // 地图上下移动初始值
          beta: 0, // 地图左右移动初始值
          distance: mapObj[options.provincesName], // 看地图的远近
          zoomSensitivity: 0, // 设置为0无法进行缩放
          orthographicSize: 100// 地图投影
        },
        label: {
          show: false
        },
        emphasis: {// 当鼠标放上去  地区区域是否显示名称
          label: {
            show: false
          },
          itemStyle: {
            color: '#07517e',
            areaColor: '#07517e'
          }
        },
        light: { // 光照阴影
          main: {
            color: '#fff', // 光照颜色
            intensity: 1.2, // 光照强度
            shadow: false, // 是否显示阴影
            alpha: 55,
            beta: 10
          },
          ambient: {
            intensity: 0.3
          }
        },
        data: arr
      }
    ]
  }
  return option
}

// 城市下的区
// options.areas数组，
// options.areas[i].areaName区名字
// options.currentAreaName选中的当前区，选传
export function drawCity (options) {
  let option
  let arr = []
  let areaColor
  for (let i = 0; i < options.areas.length; i++) {
    areaColor = options.currentAreaName ? options.areas[i].areaName.indexOf(options.currentAreaName) > -1 ? '#c8f6fe' : '#25a9e1' : '#25a9e1'
    arr.push({
      name: options.areas[i].areaName,
      itemStyle: {
        color: areaColor,
        areaColor: areaColor,
        opacity: 1,
        borderWidth: 1,
        borderColor: '#333'
      },
      emphasis: {
        itemStyle: {
          color: areaColor,
          areaColor: areaColor,
          opacity: 1,
          borderWidth: 1,
          borderColor: '#333'
        }
      }
    })
  }
  option = {
    series: [
      {
        name: 'map3D',
        type: 'map3D',
        map: options.cityName,
        itemStyle: {
          color: '#07517e',
          areaColor: '#07517e',
          opacity: 0.5,
          borderWidth: 0.4,
          borderColor: '#11c6db'
        },
        viewControl: {
          projection: 'perspective',
          maxBeta: 0, // 地图左右移动
          minBeta: 0, // 地图左右移动
          minAlpha: 90, // 地图上下移动
          maxAlpha: 90, // 地图上下移动
          alpha: 90, // 地图上下移动初始值
          beta: 0, // 地图左右移动初始值
          distance: 200, // 看地图的远近
          // zoomSensitivity: 0, // 设置为0无法进行缩放
          orthographicSize: 100// 地图投影
        },
        label: {
          show: false
        },
        emphasis: {// 当鼠标放上去  地区区域是否显示名称
          label: {
            show: false
          },
          itemStyle: {
            color: '#07517e',
            opacity: 0.5,
            areaColor: '#07517e'
          }
        },
        light: { // 光照阴影
          main: {
            color: '#fff', // 光照颜色
            intensity: 1.2, // 光照强度
            shadow: false, // 是否显示阴影
            alpha: 55,
            beta: 10
          },
          ambient: {
            intensity: 0.3
          }
        },
        data: arr
      }
    ]
  }
  return option
}

// 饼状图改变数据 typeName为数据中数据类型的名字, dataName数据的名字，默认为'count'
export function changePieData (options, typeName, dataName, type) {
  let limitLength = options.limitLength - 1 ? options.limitLength - 1 : 7
  let obj = {}
  let arr = []
  let account = 0
  let percent = 0
  let showCount = 0
  let percentAccount = 0
  let tipsArr = []
  let endArr = []
  let tipsPercent = 0
  if (dataName === undefined) {
    dataName = 'count'
  }
  for (let i = 0; i < options.length; i++) {
    account += parseFloat(options[i][dataName])
  }
  let percentValue = 0
  if (options.length > limitLength + 1) {
    for (let i = 0; i < options.length; i++) {
      percentValue = account === 0 ? 0 : options[i][dataName] / account
      if (i < limitLength) {
        if (i === options.length - 1) {
          for (let j = 0; j < arr.length; j++) {
            percentAccount += parseFloat(arr[j].percent)
          }
          percent = 100 - percentAccount
        } else {
          percent = percentValue * 100
        }
        arr.push({ name: options[i][typeName], value: options[i][dataName], percent: percent.toFixed(2) })
        tipsArr.push({ name: options[i][typeName], value: options[i][dataName], percent: percent.toFixed(2) })
      } else {
        showCount += parseFloat(options[i][dataName])
        tipsPercent = percentValue * 100
        endArr.push({ name: options[i][typeName], value: options[i][dataName], percent: tipsPercent.toFixed(2) })
      }
    }
    for (let j = 0; j < arr.length; j++) {
      percentAccount += parseFloat(arr[j].percent)
    }
    percent = 100 - percentAccount
    arr.push({ name: '其他', value: showCount, percent: percent.toFixed(2) })
    tipsArr.push(endArr)
  } else {
    for (let i = 0; i < options.length; i++) {
      percentValue = account === 0 ? 0 : options[i][dataName] / account
      if (i === options.lenth - 1) {
        for (let j = 0; j < arr.length; j++) {
          percentAccount += parseFloat(arr[i].percent)
        }
        percent = 100 - percentAccount
      } else {
        percent = percentValue * 100
      }
      arr.push({ name: options[i][typeName], value: options[i][dataName], percent: percent.toFixed(2) })
      tipsArr.push({ name: options[i][typeName], value: options[i][dataName], percent: percent.toFixed(2) })
    }
  }
  obj.data = arr
  obj.tipsArr = tipsArr
  if (type === 'notOther') {
    obj.tipsArr = tipsArr
  }
  console.log('obj===>', obj)
  return obj
}

// 柱状图改变数据, typeName 为取值的名称 divisor为取值数除以多少输出，是divisor是10000，则所输出的数值是传入数值的1/10000
export function changeBarData (options, typeName, divisor) {
  if (divisor === undefined) {
    divisor = 1
  }
  if (typeName === undefined) {
    typeName = 'count'
  }
  let arr0 = []
  let arr1 = []
  let number = 0
  for (let i = 0; i < options.length; i++) {
    for (let j = 0; j < options[i].months.length; j++) {
      if (i === 0) {
        number = parseFloat((parseFloat(options[i].months[j][typeName]) / divisor).toFixed(2))
        arr0.push(number)
      } else {
        number = parseFloat((parseFloat(options[i].months[j][typeName]) / divisor).toFixed(2))
        arr1.push(number)
      }
    }
  }
  return [arr0, arr1]
}

// 分离分公司的名字和数值dataName为数据的类型名字，如满意度的时候为rate，投诉量的时候为count
export function separateData (options, dataName, unit) {
  let obj = {}
  let dataArr = []
  let nameArr = []
  let tipsName = []
  let nameStr = ''
  let dataArr1 = []
  let dataArr2 = []
  let divisor
  if (unit) {
    divisor = unit
  } else {
    divisor = 1
  }
  for (let i = 0; i < options.length; i++) {
    if (options[i].organName.length > 7) {
      nameStr = options[i].organName.substring(0, 6) + '...'
    } else {
      nameStr = options[i].organName
    }
    tipsName.push(options[i].organName)
    nameArr.push(nameStr)
    if (Array.isArray(dataName)) {
      if (dataName.length === 1) {
        dataArr.push(parseFloat(options[i][dataName[0]]) / divisor)
      } else if (dataName.length === 2) {
        dataArr.push(parseFloat(options[i][dataName[0]]) / divisor)
        dataArr1.push(parseFloat(options[i][dataName[1]]) / divisor)
      } else {
        dataArr.push(parseFloat(options[i][dataName[0]]) / divisor)
        dataArr1.push(parseFloat(options[i][dataName[1]]) / divisor)
        dataArr2.push(parseFloat(options[i][dataName[2]]) / divisor)
      }
    } else {
      dataArr.push(parseFloat(options[i][dataName]) / divisor)
    }
  }
  obj.data = dataArr
  obj.name = nameArr
  obj.tipsName = tipsName
  if (dataArr1.length > 0) {
    obj.data1 = dataArr1
  }
  if (dataArr2.length > 0) {
    obj.data2 = dataArr2
  }
  return obj
}

// 根据数据数组和名字数组返回100%和名字，数值
// options.type ='NotOther'超出没有其他项详情提示
export function pieData (options) {
  options.limitLength = options.limitLength ? options.limitLength : 8
  let data = []
  let percentAccount = 0
  let account = 0
  let other = []
  let tipsArr = []
  if (!options.data.constructor === Array) {
    return []
  }
  options.data.forEach((item, index) => {
    account += Number(item)
  })
  let percent = 0
  options.data.forEach((item, index) => {
    percent = account === 0 ? 0 : item / account
    if (options.data.length === options.limitLength) {
      if (index === options.data.length - 1) {
        data.push({ name: options.name[index], value: item, percent: (100 - percentAccount).toFixed(2) })
      } else {
        data.push({ name: options.name[index], value: item, percent: (percent * 100).toFixed(2) })
      }
      percentAccount += percent * 100
    } else {
      if (index >= options.limitLength - 1) {
        if (data.length < options.limitLength) {
          data.push({})
        }
        data[options.limitLength - 1].value = data[options.limitLength - 1].value ? data[options.limitLength - 1].value + Number(item) : Number(item)
        data[options.limitLength - 1].name = '其他'
        data[options.limitLength - 1].percent = (100 - percentAccount).toFixed(2)
        other.push({ name: options.name[index], value: item, percent: (percent * 100).toFixed(2) })
      } else {
        data.push({ name: options.name[index], value: item, percent: (percent * 100).toFixed(2) })
        percentAccount += percent * 100
      }
    }
  })
  if (options.data.length > options.limitLength) {
    tipsArr = [...data.slice(0, options.limitLength - 1), other]
  } else {
    tipsArr = data
  }
  if (options.type === 'notOther') {
    tipsArr = data
  }
  return { data: data, tipsArr: tipsArr }
}

// 二维地图
export function getMapOption2D (options) {
  let arr = []
  let obj = {}
  for (let i = 0; i < options.length; i++) {
    arr.push(options[i].provinceName)
  }
  let provinceArr = dislodge(arr)
  let regionsArr = []
  for (let i = 0; i < provinceArr.length; i++) {
    regionsArr.push(
      {
        name: provinceArr[i],
        itemStyle: {
          normal: {
            color: '#25a9e1',
            areaColor: '#25a9e1',
            opacity: 1,
            borderWidth: 1,
            borderColor: '#333'
          },
          emphasis: {
            areaColor: '#25a9e1',
            color: '#25a9e1',
            opacity: 1,
            borderWidth: 1,
            borderColor: '#333'
          }
        },
        label: {
          emphasis: {
            show: false,
            textStyle: {
              color: '#fff',
              fontSize: 3,
              backgroundColor: 'rgba(7, 23, 62, 0.8)',
              borderColor: '#1072e2',
              borderWidth: 1
            }
          }
        }
      }
    )
  }
  obj.option = {
    series: [
      {
        name: 'map',
        type: 'map',
        map: 'china',
        z: 5,
        zlevel: 10,
        itemStyle: {
          normal: {
            areaColor: '#07517e',
            opacity: 0.5,
            borderWidth: 0.4,
            borderColor: '#11c6db'
          },
          emphasis: {
            color: 'black',
            areaColor: '#07517e'
          }
        },
        label: {
          normal: {
            show: false,
            textStyle: {
              color: '#fff',
              fontSize: 14,
              backgroundColor: 'rgba(7, 23, 62, 0.8)',
              borderColor: '#1072e2',
              borderWidth: 14
            }
          },
          emphasis: {
            show: false,
            textStyle: {
              color: '#fff',
              fontSize: 14,
              backgroundColor: 'rgba(0,23,11,0)'
            }
          }
        },
        data: regionsArr
      },
      {
        name: 'map',
        type: 'map',
        silent: true,
        mapType: 'china',
        zoom: 1.2,
        z: -1,
        zlevel: 0,
        label: {
          normal: {
            show: false
          },
          emphasis: {
            show: false
          }
        },
        itemStyle: {
          normal: {
            color: 'transparent',
            areaColor: 'transparent',
            opacity: 0
          }
        },
        data: [
          {
            name: '南海诸岛',
            itemStyle: {
              normal: {
                areaColor: '#25a9e1',
                color: '#25a9e1',
                opacity: 0.5
              },
              emphasis: {
                areaColor: '#25a9e1',
                color: '#25a9e1',
                opacity: 0.5
              }
            }
          }
        ]
      }
    ]
  }
  obj.arr = provinceArr
  return obj
}

export function drawing2D (options) {
  let option = null
  let arr = []
  for (let i = 0; i < options.citys.length; i++) {
    arr.push({
      name: options.citys[i].cityName,
      itemStyle: {
        normal: {
          color: '#25a9e1',
          areaColor: '#25a9e1',
          opacity: 1,
          borderWidth: 1,
          borderColor: '#333'
        },
        emphasis: {
          itemStyle: {
            color: '#25a9e1',
            areaColor: '#25a9e1',
            opacity: 1,
            borderWidth: 1,
            borderColor: '#333'
          }
        }
      }
    })
  }
  option = {
    series: [
      {
        name: 'map',
        type: 'map',
        map: options.provincesName,
        itemStyle: {
          normal: {
            color: '#07517e',
            areaColor: '#07517e',
            opacity: 0.5,
            borderWidth: 0.4,
            borderColor: '#11c6db'
          },
          emphasis: {
            color: '#07517e',
            areaColor: '#07517e'
          }
        },
        label: {
          normal: {
            show: false
          },
          emphasis: {
            show: false
          }
        },
        data: arr
      }
    ]
  }
  return option
}

export function drawCity2D (options) {
  let option
  let arr = []
  let areaColor
  for (let i = 0; i < options.areas.length; i++) {
    areaColor = options.currentAreaName ? options.areas[i].areaName.indexOf(options.currentAreaName) > -1 ? '#c8f6fe' : '#25a9e1' : '#25a9e1'
    arr.push({
      name: options.areas[i].areaName,
      itemStyle: {
        normal: {
          color: areaColor,
          areaColor: areaColor,
          opacity: 1,
          borderWidth: 1,
          borderColor: '#333'
        },
        emphasis: {
          color: areaColor,
          areaColor: areaColor,
          opacity: 1,
          borderWidth: 1,
          borderColor: '#333'
        }
      }
    })
  }
  option = {
    series: [
      {
        name: 'map',
        type: 'map',
        map: options.cityName,
        itemStyle: {
          normal: {
            color: '#07517e',
            areaColor: '#07517e',
            opacity: 0.5,
            borderWidth: 0.4,
            borderColor: '#11c6db'
          },
          emphasis: {
            opacity: 0.5,
            color: '#07517e',
            areaColor: '#07517e'
          }
        },
        label: {
          normal: {
            show: false
          },
          emphasis: {
            show: false
          }
        },
        data: arr
      }
    ]
  }
  return option
}
